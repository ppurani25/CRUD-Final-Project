alert("Hello and Welcome! Please enter your name and email to be displayed on this university website!");

function revealmessage() {
    document.getElementById("hiddenmessage").style.display = 'block';
}